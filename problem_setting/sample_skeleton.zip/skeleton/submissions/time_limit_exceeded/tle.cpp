#include <iostream>

using namespace std;

// This is a TLE solution that does nothing but an infinite loop.
int main() {
  while (true);
  return 0;
}
