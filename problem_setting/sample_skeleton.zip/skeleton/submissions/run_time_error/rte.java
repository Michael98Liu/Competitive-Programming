import java.io.*;
import java.util.*;

public class rte {
  public static void main(String[] args) throws IOException {
    Scanner sc = new Scanner(System.in);
    // Create a huge array and exhaust the memory
    int n = 100000;
    int[][] arr = new int[n][n];
  }
}
